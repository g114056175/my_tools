# VideoPocket FFmpeg single-thread corresponding source

## Exact source

- Project: FFmpeg
- Release: `n5.1.4` / version `5.1.4`
- Official source URL: `https://ffmpeg.org/releases/ffmpeg-5.1.4.tar.gz`
- Official source archive SHA-256: `6ED8BA17D513955CD9A03D0D87195B8EAC3D148DCB61EF30EBDDF1A3CD718DE8`
- Source tree in this bundle: `ffmpeg-n5.1.4-source/`

The source tree contains no generated object files, Emscripten SDK, compiler binaries, or build cache. The VideoPocket-specific local change is embedded in `fftools/ffmpeg.c`: under `__EMSCRIPTEN__`, `HAVE_GETRUSAGE` and `HAVE_STRUCT_RUSAGE_RU_MAXRSS` are disabled so the browser's placeholder process-resource shim is not queried by optional benchmark reporting. This does not alter media processing or the normal clock path.

## Rebuild

Use Emscripten `3.1.40` and `wasm-opt`, then run `build-single.sh` from the parent `slim-ffmpeg-build` directory. The script expects `emsdk/`, `src/ffmpeg-n5.1.4/`, and `wasm-opt` beside it, and uses `mingw32-make -j1` for the single-thread final link. It postprocesses WebAssembly with `wasm-opt -Oz --strip-debug --strip-producers`.

The SDK/toolchain (about 425 MB), generated objects, and build cache are intentionally excluded. Host toolchain differences may prevent bit-for-bit reproduction.

## Current browser bundle

| file | bytes | SHA-256 |
|---|---:|---|
| `extension/vendor/ffmpeg-core.js` | 207,964 | `AE48201D0456EB136F050869798A2C448FD91F422019E2F05365BEE1A1724AAD` |
| `extension/vendor/ffmpeg-core.wasm` | 4,664,753 | `3A9EAFAFDC05535CF5FD651182C8B421077D159DA43120DAD5F814CD882C72B1` |

The worker helper is not part of this single-thread source package.

## Licensing

FFmpeg terms are in `COPYING.LGPLv2.1`; Emscripten terms are in `Emscripten-LICENSE.txt`. No external codec libraries or encoders are enabled by this configuration.
