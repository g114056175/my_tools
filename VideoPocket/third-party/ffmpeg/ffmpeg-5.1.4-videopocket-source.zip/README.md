# VideoPocket FFmpeg 5.1.4 corresponding source

This archive contains the complete FFmpeg `n5.1.4` source tree, the VideoPocket single-thread Emscripten build scripts, and applicable license texts for the browser bundle in `extension/vendor/`.

The source tree is based on the official FFmpeg release archive `ffmpeg-5.1.4.tar.gz` (SHA-256: `6ED8BA17D513955CD9A03D0D87195B8EAC3D148DCB61EF30EBDDF1A3CD718DE8`). The local browser patch is retained in `fftools/ffmpeg.c`: for `__EMSCRIPTEN__` it disables only optional `getrusage` and `ru_maxrss` benchmark fields, whose browser shim reports placeholder process statistics. Media processing and the normal clock path remain enabled. No FFmpeg source file or build script is changed by this publication packaging step.

## Rebuild

Use Emscripten 3.1.40 and its `wasm-opt`, place the source tree at the location expected by `build-single.sh`, and run that script from the parent `slim-ffmpeg-build` directory. The script uses a single-thread build (`mingw32-make -j1`), then runs:

```text
wasm-opt -Oz --strip-debug --strip-producers
```

The Emscripten SDK, compiler binaries, `wasm-opt`, generated objects, and build cache are intentionally excluded. Host toolchain differences may prevent bit-for-bit reproduction.

## Bundle correspondence

| file | bytes | SHA-256 |
|---|---:|---|
| `extension/vendor/ffmpeg-core.js` | 207,964 | `AE48201D0456EB136F050869798A2C448FD91F422019E2F05365BEE1A1724AAD` |
| `extension/vendor/ffmpeg-core.wasm` | 4,664,753 | `3A9EAFAFDC05535CF5FD651182C8B421077D159DA43120DAD5F814CD882C72B1` |

The matching browser bundle is built from this patched source with the configuration recorded in `build-single.sh`. The source package does not contain generated JavaScript or WebAssembly files.

## Licensing

This configuration uses FFmpeg's native LGPL components and no external codec libraries. FFmpeg terms are in `COPYING.LGPLv2.1`; Emscripten terms are in `Emscripten-LICENSE.txt`.
