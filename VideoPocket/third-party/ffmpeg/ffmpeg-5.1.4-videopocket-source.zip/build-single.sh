#!/usr/bin/env bash
set -euxo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
source "$ROOT/emsdk/emsdk_env.sh"
export PATH="$ROOT/emsdk/upstream/emscripten:$ROOT/emsdk/upstream/bin:$PATH"
export EMSDK_PYTHON="$ROOT/emsdk/python/3.13.3_64bit/python.exe"
export EMSDK_NODE="$ROOT/emsdk/node/24.19.0_64bit/node.exe"
SRC="$ROOT/src/ffmpeg-n5.1.4"
OUT="$ROOT/bundle-single"
mkdir -p "$OUT"
cd "$SRC"
make distclean >/dev/null 2>&1 || true
export CC=emcc CXX=em++ LD=emcc AR=emar NM=emnm RANLIB=emranlib STRIP=emstrip
./configure \
  --target-os=none --arch=wasm32 --cpu=generic --enable-cross-compile \
  --cc=emcc --cxx=em++ --ld=emcc --ar=emar --nm=emnm --ranlib=emranlib --strip=emstrip \
  --disable-x86asm --disable-pthreads --disable-w32threads --disable-os2threads \
  --disable-debug --disable-doc --disable-programs --disable-everything \
  --enable-ffmpeg --enable-protocol=file --enable-protocol=pipe \
  --enable-demuxer=mov --enable-demuxer=matroska --enable-demuxer=mpegts --enable-demuxer=flv --enable-demuxer=ogg --enable-demuxer=mp3 --enable-demuxer=aac \
  --enable-muxer=mp4 --enable-muxer=ipod --enable-muxer=webm --enable-muxer=matroska --enable-muxer=mpegts --enable-muxer=flv --enable-muxer=ogg --enable-muxer=mp3 --enable-muxer=adts \
  --enable-parser=h264 --enable-parser=hevc --enable-parser=vp8 --enable-parser=vp9 --enable-parser=av1 --enable-parser=aac --enable-parser=opus --enable-parser=mpeg4video --enable-parser=mpegaudio \
  --enable-decoder=h264 --enable-decoder=hevc --enable-decoder=vp8 --enable-decoder=vp9 --enable-decoder=av1 --enable-decoder=aac --enable-decoder=opus --enable-decoder=mp3 --enable-decoder=vorbis --enable-decoder=flac --enable-decoder=mpeg4 --enable-decoder=mpeg2video --enable-decoder=ac3 --enable-decoder=eac3 --enable-decoder=theora --enable-decoder=webp \
  --enable-filter=null --enable-filter=aresample --enable-filter=scale \
  --enable-bsf=aac_adtstoasc --enable-bsf=extract_extradata --enable-bsf=h264_mp4toannexb --enable-bsf=hevc_mp4toannexb --enable-muxer=null \
  --extra-cflags='-O3 -ffunction-sections -fdata-sections' \
  --extra-ldflags='-Wl,--gc-sections -lworkerfs.js -sWASM_BIGINT=1 -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=67108864 -sMAXIMUM_MEMORY=2147483648 -sENVIRONMENT=web,worker -sFILESYSTEM=1 -sMODULARIZE=1 -sEXPORT_ES6=0 -sEXPORT_NAME=createFFmpegCore -sINVOKE_RUN=0 -sEXIT_RUNTIME=0 -sEXPORTED_RUNTIME_METHODS=[callMain,FS]'
mingw32-make -j1 V=0 ffmpeg_g
cp ffmpeg_g "$OUT/ffmpeg-core.js"
wasm-opt -Oz --strip-debug --strip-producers -o "$OUT/ffmpeg-core.wasm" ffmpeg_g.wasm
sha256sum "$OUT"/*
wc -c "$OUT"/*
